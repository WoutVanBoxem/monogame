﻿
using var game = new Monogame.Game1();
game.Run();
